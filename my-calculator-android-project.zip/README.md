# My Calculator — Android App

A simple native Android application built with **Python + Kivy + Buildozer**.

## Features

- Addition
- Subtraction
- Multiplication
- Division
- Decimal numbers
- Percentage
- Positive/negative toggle
- Backspace
- Clear
- Portrait Android layout
- Automatic APK builds with GitHub Actions

## Project files

- `main.py` — calculator application
- `buildozer.spec` — Android/Buildozer configuration
- `.github/workflows/android.yml` — automatic APK builder

## Build the APK on GitHub

1. Upload these project files to the repository root.
2. Commit/push them to `main`.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Wait for the workflow to finish.
6. Open the completed workflow run.
7. Download the `calculator-apk` artifact.
8. Extract the APK and install it on an Android phone.

## Local build

Install Buildozer and its Android build dependencies, then run:

```bash
buildozer android debug
```

The generated APK will be placed in the `bin/` directory.
