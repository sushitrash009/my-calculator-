[app]
title = My Calculator
package.name = mycalculator
package.domain = com.sushitrash009

source.dir = .
source.include_exts = py,png,jpg,kv,atlas

version = 1.0

requirements = python3,kivy

orientation = portrait
fullscreen = 0

# Android
android.api = 35
android.minapi = 23
android.archs = arm64-v8a

# App permissions
android.permissions =

[buildozer]
log_level = 2
warn_on_root = 1
